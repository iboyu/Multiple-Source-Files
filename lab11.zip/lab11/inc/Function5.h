#ifndef FUNCTION5_H
#define FUNCTION5_H

#endif
#include "lab11.h"
void Function5();