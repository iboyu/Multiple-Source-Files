#ifndef FUNCTION3_H
#define FUNCTION3_H

#endif
#include "lab11.h"
void Function3();