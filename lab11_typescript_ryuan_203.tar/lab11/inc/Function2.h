#ifndef FUNCTION2_H
#define FUNCTION2_H

#endif
#include "lab11.h"
void Function2();