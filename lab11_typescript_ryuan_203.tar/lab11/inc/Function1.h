#ifndef FUNCTION1_H
#define FUNCTION1_H

#endif
#include "lab11.h"
void Function1();