#include <stdio.h>
#include <stdlib.h>

#include "lab11.h"
#include "Function1.h"
#include "Function2.h"
#include "Function3.h"
#include "Function4.h"
#include "Function5.h"

int main(int argc, char **argv)
{
    Function1();
    Function2();
    Function3();
    Function4();
    Function5();

}